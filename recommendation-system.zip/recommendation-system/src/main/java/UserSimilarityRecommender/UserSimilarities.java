package UserSimilarityRecommender;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.UserBasedRecommender;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class UserSimilarities {
    DataModel model;
    public void userSimilarityRecommender() throws TasteException {

        //Where the JSON file is located
        getDocument();

        UserSimilarity userSimilarity = new PearsonCorrelationSimilarity(model);

        //Use the nearest 1 to compare
        UserNeighborhood neighborhood = new NearestNUserNeighborhood(1,userSimilarity, model);

        UserBasedRecommender recommender = new GenericUserBasedRecommender(model, neighborhood, userSimilarity);

        // Returns back a list of items for the specific user (USER: 2)
        List<RecommendedItem> recommendations = recommender.recommend(2, 2);

        for (RecommendedItem recommendation : recommendations) {
            System.out.println(recommendation);
        }
    }

    private void getDocument() {
        try {
            model = new FileDataModel(new File("src/main/resources/sales-report.json"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

