import ItemSimilarityRecommender.ItemSimilarities;
import UserSimilarityRecommender.UserSimilarities;
import org.apache.mahout.cf.taste.common.TasteException;

public class RecommendationSystemApp {

    private static ItemSimilarities itemSimilarities;
    private static UserSimilarities userSimilarities;

    public static void main(String[] args) throws TasteException {
        itemSimilarities.itemSimilarityRecommender();
        userSimilarities.userSimilarityRecommender();
    }

}
