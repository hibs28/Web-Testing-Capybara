package ItemSimilarityRecommender;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.recommender.GenericItemBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.GenericItemSimilarity;
import org.apache.mahout.cf.taste.impl.similarity.LogLikelihoodSimilarity;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.recommender.ItemBasedRecommender;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.similarity.ItemSimilarity;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

public class ItemSimilarities {

    DataModel model;

    public void itemSimilarityRecommender() throws TasteException {

        //Where the JSON file is located
        getDocument();

        //Should use GenericItemSimilarity instead
        ItemSimilarity itemSimilarity = new LogLikelihoodSimilarity(model);

        ItemBasedRecommender recommender = new GenericItemBasedRecommender(model, itemSimilarity);

        List<RecommendedItem> recommendations = recommender.recommend(2, 2);

        for (RecommendedItem recommendation : recommendations) {
            System.out.println(recommendation);
        }
    }

    private void getDocument() {
        try {
            model = new FileDataModel(new File("src/main/resources/sales-report.json"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}